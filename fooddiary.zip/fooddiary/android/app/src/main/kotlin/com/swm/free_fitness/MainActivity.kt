package com.swm.fit_track

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
