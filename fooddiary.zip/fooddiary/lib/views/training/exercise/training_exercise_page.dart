import 'package:flutter/cupertino.dart';

class TrainingExercisePage extends StatefulWidget {
  const TrainingExercisePage({super.key});

  @override
  State<TrainingExercisePage> createState() => _TrainingExercisePageState();
}

class _TrainingExercisePageState extends State<TrainingExercisePage> {
  @override
  void initState() {
    loadJson();
    super.initState();
  }
  void loadJson() {

  }
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }


}
